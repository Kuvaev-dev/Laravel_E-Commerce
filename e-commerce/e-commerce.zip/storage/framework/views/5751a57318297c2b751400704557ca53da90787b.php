<div>
    <div class="container" style="padding: 30px 0">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-6">
                                Add New Member
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('admin.members')); ?>" class="btn btn-success pull-right">All Members</a>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                        <?php endif; ?>
                        <form class="form-horizontal" enctype="multipart/form-data" wire:submit.prevent="addMember()">
                            <div class="form-group">
                                <label class="col-md-4 control-label">Member Name</label>
                                <div class="col-md-4">
                                    <input type="text" placeholder="Member Name" class="form-control input-md" wire:model="name"/>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <p class="text-danger"><?php echo e($message); ?></p>   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-4 control-label">Member Work</label>
                                <div class="col-md-4">
                                    <input type="text" placeholder="Member Work" class="form-control input-md" wire:model="work"/>
                                    <?php $__errorArgs = ['work'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <p class="text-danger"><?php echo e($message); ?></p>   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-4 control-label">Member Description</label>
                                <div class="col-md-4" wire:ignore>
                                    <textarea class="form-control" id="member_description" placeholder="Member Description" wire:model="description"></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <p class="text-danger"><?php echo e($message); ?></p>   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-4 control-label">Member Photo</label>
                                <div class="col-md-4">
                                    <input type="file" class="input-file" wire:model="photo"/>
                                    <?php if($photo): ?>
                                        <img src="<?php echo e($photo->temporaryUrl()); ?>" width="120"/>
                                    <?php endif; ?>
                                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <p class="text-danger"><?php echo e($message); ?></p>   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-4 control-label"></label>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary">Add</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(function () {
            tinymce.init({
                selector: '#member_description',
                setup: function (editor) {
                    editor.on('Change', function (e) {
                        tinyMCE.triggerSave();
                        var d_data = $('#member_description').val();
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('member_description', d_data);
                    })
                }
            });
        })
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\Nikita\Desktop\Laravel_E-Commerce\e-commerce\resources\views/livewire/admin/admin-add-member-component.blade.php ENDPATH**/ ?>