<div>
    <style>
        nav svg{
            height: 20px;
        }
        nav .hidden{
            display: block !important;
        }
    </style>
    <div class="container" style="padding: 30px 0;">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-4">
                                All Members
                            </div>
                            <div class="col-md-8">
                                <a href="<?php echo e(route('admin.addmembers')); ?>" class="btn btn-success pull-right">Add New</a>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                        <?php endif; ?>
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Work</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($member->id); ?></td>
                                    <td><img src="<?php echo e(asset('assets/images/members')); ?>/<?php echo e($member->photo); ?>" width="60"/></td>
                                    <td><?php echo e($member->name); ?></td>
                                    <td><?php echo e($member->work); ?></td>
                                    <td><?php echo e($member->description); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.editmember', ['member_id' => $member->id])); ?>"><i class="fa fa-edit fa-2x text-info"></i></a>
                                        <a href="#" onclick="confirm('Are you sure, you want delete this member?') || event.stopImmediatePropagation()" style="margin-left: 10px;" wire:click.prevent="deleteMember(<?php echo e($member->id); ?>)"><i class="fa fa-times fa-2x text-danger"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Nikita\Desktop\Laravel_E-Commerce\e-commerce\resources\views/livewire/admin/admin-members-component.blade.php ENDPATH**/ ?>